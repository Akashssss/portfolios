﻿using Food_Order.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Food_Order.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly DataContext _context;
        public OrderController(DataContext context)
        {
            _context= context;
        }

        [HttpPost]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderDto createOrderDto)
        {
          

            var customer = await _context.Customers.FindAsync(createOrderDto.CustomerId);
            if (customer == null)
            {
                return NotFound("Customer not found");
            }

            var order = new Order
            {
                CustomerId = createOrderDto.CustomerId,
                OrderDate = createOrderDto.OrderDate,
                OrderProducts = createOrderDto.Products.Select(p => new OrderProduct
                {
                    ProductId = p.ProductId,
                    Quantity = p.Quantity
                }).ToList()
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOrderById), new { id = order.Id }, order);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrderById(int id)
        {
            var order = await _context.Orders
                                      .Include(o => o.OrderProducts)
                                      .ThenInclude(op => op.Product)
                                      .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            return Ok(order);
        }



        // PUT: api/orders/{orderId}
        [HttpPut("{orderId}")]
        public async Task<IActionResult> UpdateOrder(int orderId, [FromBody] UpdateOrderDto updateOrderDto)
        {
            var order = await _context.Orders
                                      .Include(o => o.OrderProducts)
                                      .FirstOrDefaultAsync(o => o.Id == orderId);

            if (order == null)
            {
                return NotFound("Order not found");
            }

            if (order.CustomerId != updateOrderDto.CustomerId)
            {
                return Unauthorized("You do not have permission to update this order");
            }

            // Update order details
            order.OrderDate = updateOrderDto.OrderDate;

            // Get current order products
            var existingOrderProducts = order.OrderProducts.ToList();

            // Remove products that are no longer in the updated list
            var productsToRemove = existingOrderProducts
                .Where(op => !updateOrderDto.Products.Any(p => p.ProductId == op.ProductId))
                .ToList();
            _context.OrderProduct.RemoveRange(productsToRemove);

            // Update quantities and add new products
            foreach (var productDto in updateOrderDto.Products)
            {
                var existingProduct = existingOrderProducts
                    .FirstOrDefault(op => op.ProductId == productDto.ProductId);

                if (existingProduct != null)
                {
                    // Update existing product quantity
                    existingProduct.Quantity = productDto.Quantity;
                }
                else
                {
                    // Add new product
                    order.OrderProducts.Add(new OrderProduct
                    {
                        ProductId = productDto.ProductId,
                        Quantity = productDto.Quantity
                    });
                }
            }

            // Save changes
            await _context.SaveChangesAsync();

            return Ok(order);
        }

        // DELETE: api/orders/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            var order = await _context.Orders
                                      .Include(o => o.OrderProducts)
                                      .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            _context.OrderProduct.RemoveRange(order.OrderProducts);
            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // GET: api/orders/customer/{customerId}
        [HttpGet("customer/{customerId}")]
        public async Task<IActionResult> GetOrdersByCustomerId(int customerId)
        {
            var orders = await _context.Orders
                                       .Where(o => o.CustomerId == customerId)
                                       .Include(o => o.OrderProducts)
                                       .ThenInclude(op => op.Product)
                                       .ToListAsync();

            if (!orders.Any())
            {
                return NotFound("No orders found for this customer");
            }

            return Ok(orders);
        }
    }


}

