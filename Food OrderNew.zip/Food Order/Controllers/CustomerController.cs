﻿using Food_Order.Data;
using Food_Order.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Food_Order.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {


        private readonly DataContext _context;
        public CustomerController(DataContext context)
        {
            _context = context;
        }


        [HttpPost]
        public async Task<IActionResult> CreateCustomer(CustomerDto customerDto)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            bool emailExist = await _context.Customers.AnyAsync(c => c.Email ==  customerDto.Email);
            
            if(emailExist)
                return Conflict( "The email address is already in use.");

            bool PhoneExist = await _context.Customers.AnyAsync(c => c.Phone ==  customerDto.Phone);
            if (PhoneExist)
                return Conflict("The Phone number is already in use.");
            
            var customer = new Customer {

                FirstName = customerDto.FirstName,
                LastName = customerDto.LastName,
                Phone = customerDto.Phone,
                Email = customerDto.Email,
                Address = customerDto.Address
            };

            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCustomerById), new { id = customer.Id }, customer);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetCustomerById(int id)
        {
            var customer = await _context.Customers
                                          .Include(c => c.Orders)
                                          .ThenInclude(o => o.OrderProducts)
                                          .ThenInclude(op => op.Product)
                                          .FirstOrDefaultAsync(c => c.Id == id);

            if (customer == null)
            {
                return NotFound();
            }

            return Ok(customer);
        }


        [HttpGet]
        public async Task<IActionResult> GetAllCustomers()
        {
            var customers = await _context.Customers
                                          .ToListAsync();

            return Ok(customers);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCustomer(int id, [FromBody] CustomerDto customerDto)
        {
           

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            customer.FirstName = customerDto.FirstName;
            customer.LastName = customerDto.LastName;
            customer.Phone = customerDto.Phone;
            customer.Email = customerDto.Email;
            customer.Address = customerDto.Address;

            await _context.SaveChangesAsync();

            return NoContent();
        }



        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            var customer = await _context.Customers
                                          .Include(c => c.Orders)
                                          .ThenInclude(o => o.OrderProducts)
                                          .FirstOrDefaultAsync(c => c.Id == id);

            if (customer == null)
            {
                return NotFound();
            }

            _context.OrderProduct.RemoveRange(customer.Orders.SelectMany(o => o.OrderProducts));
            _context.Orders.RemoveRange(customer.Orders);
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }




}

