﻿using System.ComponentModel.DataAnnotations;

namespace Food_Order.Model
{
    public class UpdateOrderDto
    {
        [Required]
        public int CustomerId { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        [Required]
        public List<OrderProductDto> Products { get; set; } = new List<OrderProductDto>();
    }
}
